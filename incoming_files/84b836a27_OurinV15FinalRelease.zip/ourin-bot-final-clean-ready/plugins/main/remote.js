import { alyaHeader, bracketBox, separator, tipText } from "../../src/lib/ourin-menu-style.js";

const pluginConfig = {
  name: "remote",
  alias: ["remote", "remotecontrol", "controlbot"],
  category: "owner",
  description: "Kontrol bot dari jarak jauh",
  usage: ".remote <perintah>",
  example: ".remote eval 1+1",
  isOwner: true,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  energi: 0,
  isEnabled: true,
};

async function handler(m, { sock, config: botConfig }) {
  try {
    const prefix = botConfig.command?.prefix || ".";

    const text =
      alyaHeader("Remote", "🎮") +
      "\n\n" +
      bracketBox("🎮", "ᴄᴏɴᴛʀᴏʟ", [
        "◦ Fitur remote control aktif.",
        "◦ Gunakan perintah yang valid.",
      ]) +
      "\n\n" +
      separator("━", 22) +
      "\n" +
      tipText(`Ketik ${prefix}menu untuk kembali`);

    await m.reply(text);
  } catch (error) {
    const prefix = botConfig.command?.prefix || ".";
    const text =
      alyaHeader("Gagal", "❌") +
      "\n\n" +
      bracketBox("❌", "ᴇʀʀᴏʀ", [
        `◦ Status: *Gagal*`,
        `◦ Alasan: *${error.message}*`,
      ]) +
      "\n\n" +
      separator("━", 22) +
      "\n" +
      tipText(`Coba lagi nanti atau hubungi owner`);

    await m.reply(text);
  }

  return { handled: true };
}

export default {
  config: pluginConfig,
  handler,
};
