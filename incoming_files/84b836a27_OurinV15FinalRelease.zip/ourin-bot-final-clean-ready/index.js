import path from "path";
import fs from "fs";
import config from "./config.js";
import { startConnection } from "./src/connection.js";
let messageHandler = async () => {};
let messageUpdateHandler = async () => {};
let groupHandler = null;
let groupSettingsHandler = async () => {};
let handleAntiRemoveFromUpsert = async () => {};
try {
  const handlerMod = await import("./src/handler.js");
  if (typeof handlerMod.messageHandler === "function") messageHandler = handlerMod.messageHandler;
  if (typeof handlerMod.messageUpdateHandler === "function") messageUpdateHandler = handlerMod.messageUpdateHandler;
  if (typeof handlerMod.groupHandler === "function") groupHandler = handlerMod.groupHandler;
  if (typeof handlerMod.groupSettingsHandler === "function") groupSettingsHandler = handlerMod.groupSettingsHandler;
  if (typeof handlerMod.handleAntiRemoveFromUpsert === "function") handleAntiRemoveFromUpsert = handlerMod.handleAntiRemoveFromUpsert;
} catch {}
import { loadPlugins, pluginStore } from "./src/lib/ourin-plugins.js";
import { initDatabase, getDatabase } from "./src/lib/ourin-database.js";
import {
  initScheduler,
  loadScheduledMessages,
  startGroupScheduleChecker,
  startSewaChecker,
} from "./src/lib/ourin-scheduler.js";
import { handleAntiTagSW } from "./src/lib/ourin-group-protection.js";
import {
  logger,
  c,
  playBootSequence,
  spinText,
  logConnection,
  logErrorBox,
  divider,
} from "./src/lib/ourin-logger.js";

async function safeDynamicImport(spec) {
  try {
    const mod = await import(spec);
    return mod;
  } catch (error) {
    const missing = String(error?.message || "");
    const name = spec.replace("./", "");
    logger.warn("bootstrap", `dynamic import failed: ${name} -> ${missing}`);
    if (missing.includes("ERR_MODULE_NOT_FOUND") || missing.includes("Cannot find module")) {
      const m = missing.match(/['"](.*?)['"]/);
      const mod = m ? m[1] : "unknown";
      logger.warn("bootstrap", `missing module skipped: ${name} | unresolved: ${mod}`);
    }
    return null;
  }
}

let _initSholatScheduler = null;
let _initNotifScheduler = null;
let _initWeatherScheduler = null;
let _initLokerScheduler = null;
let _initAutoJpmScheduler = null;
let _startMemoryMonitor = null;
let _startTempCleaner = null;
let _startDailyPruner = null;
let _ourinAgent = null;

await safeDynamicImport("./src/lib/ourin-agent.js").then((m) => { _ourinAgent = m; });
_initSholatScheduler = await safeDynamicImport("./src/lib/ourin-sholat-scheduler.js").then((m) => typeof m?.initSholatScheduler === "function" ? m.initSholatScheduler : null);
_initNotifScheduler = await safeDynamicImport("./src/lib/ourin-notif-scheduler.js").then((m) => typeof m?.initNotifScheduler === "function" ? m.initNotifScheduler : null);
_initWeatherScheduler = await safeDynamicImport("./src/lib/ourin-weather-scheduler.js").then((m) => typeof m?.initWeatherScheduler === "function" ? m.initWeatherScheduler : null);
_initLokerScheduler = await safeDynamicImport("./src/lib/ourin-loker-scheduler.js").then((m) => typeof m?.initLokerScheduler === "function" ? m.initLokerScheduler : null);
_initAutoJpmScheduler = await safeDynamicImport("./src/lib/ourin-auto-jpm.js").then((m) => typeof m?.initAutoJpmScheduler === "function" ? m.initAutoJpmScheduler : null);
_startMemoryMonitor = await safeDynamicImport("./src/lib/ourin-memory-monitor.js").then((m) => typeof m?.startMemoryMonitor === "function" ? m.startMemoryMonitor : null);
_startTempCleaner = await safeDynamicImport("./src/lib/ourin-temp-cleaner.js").then((m) => typeof m?.startTempCleaner === "function" ? m.startTempCleaner : null);
_startDailyPruner = await safeDynamicImport("./src/lib/ourin-data-pruner.js").then((m) => typeof m?.startDailyPruner === "function" ? m.startDailyPruner : null);

try { if (_ourinAgent?.initializeAgent) await _ourinAgent.initializeAgent(); } catch {}

const LOG_NOISE = new Set([
  "Closing",
  "prekey",
  "_chains",
  "registrationId",
  "chainKey",
  "ephemeralKeyPair",
  "rootKey",
  "indexInfo",
  "pendingPreKey",
  "currentRatchet",
  "baseKey",
  "privKey",
]);
const _log = console.log;
console.log = (...args) => {
  const first = typeof args[0] === "string" ? args[0] : "";
  for (const noise of LOG_NOISE) {
    if (first.includes(noise)) return;
  }
  _log.apply(console, args);
};

const startTime = Date.now();

let pluginWatcher = null;
const reloadDebounce = new Map();
const fileStatCache = new Map();

function startDevWatcher(pluginsPath) {
  if (pluginWatcher) pluginWatcher.close();

  logger.system("dev", "Hot-Reload watcher active for plugins");

  pluginWatcher = fs.watch(
    pluginsPath,
    { recursive: true },
    (eventType, filename) => {
      if (!filename || !filename.endsWith(".js")) return;

      const existingTimeout = reloadDebounce.get(filename);
      if (existingTimeout) clearTimeout(existingTimeout);

      const timeout = setTimeout(async () => {
        reloadDebounce.delete(filename);
        const fullPath = path.join(pluginsPath, filename);

        if (!fs.existsSync(fullPath)) {
          fileStatCache.delete(fullPath);
          const pluginName = path.basename(filename, ".js");
          const { unloadPlugin } = await import("./src/lib/ourin-plugins.js");
          const result = unloadPlugin(pluginName);
          if (result.success) logger.warn("plugin", `removed ${filename}`);
          return;
        }

        try {
          const stats = fs.statSync(fullPath);
          const cached = fileStatCache.get(fullPath);
          const changed =
            !cached ||
            cached.mtimeMs !== stats.mtimeMs ||
            cached.size !== stats.size;
          if (!changed) return;

          fileStatCache.set(fullPath, {
            mtimeMs: stats.mtimeMs,
            size: stats.size,
          });

          const { hotReloadPlugin } =
            await import("./src/lib/ourin-plugins.js");
          const result = await hotReloadPlugin(fullPath);
          if (!result.success) {
            logger.error(
              "plugin",
              `reload failed: ${filename}: ${result.error}`,
            );
          }
        } catch (error) {
          logger.error(
            "plugin",
            `reload failed: ${filename}: ${error.message}`,
          );
        }
      }, 500);

      reloadDebounce.set(filename, timeout);
    },
  );

  logger.debug("dev", `Monitoring directory: ${pluginsPath}`);
}

let srcWatcher = null;

function startSrcWatcher(srcPath) {
  if (srcWatcher) srcWatcher.close();

  logger.system("dev", "Hot-Reload watcher active for src");

  srcWatcher = fs.watch(srcPath, { recursive: true }, (eventType, filename) => {
    if (!filename || !filename.endsWith(".js")) return;

    const existingTimeout = reloadDebounce.get("src_" + filename);
    if (existingTimeout) clearTimeout(existingTimeout);

    const timeout = setTimeout(() => {
      reloadDebounce.delete("src_" + filename);
      const fullPath = path.join(srcPath, filename);
      if (!fs.existsSync(fullPath)) {
        logger.warn("dev", `src file removed: ${filename}`);
        return;
      }
      logger.success("dev", `src changed: ${filename}`);
    }, 500);

    reloadDebounce.set("src_" + filename, timeout);
  });

  logger.debug("dev", `Monitoring directory: ${srcPath}`);
}

function setupAntiCrash() {
  process.on("uncaughtException", (error, origin) => {
    const ignoredErrors = [
      "write EOF",
      "ECONNRESET",
      "EPIPE",
      "ETIMEDOUT",
      "ENOTFOUND",
      "ECONNREFUSED",
      "read ECONNRESET",
    ];
    const isIgnored = ignoredErrors.some(
      (msg) => error.message?.includes(msg) || error.code === msg,
    );
    if (isIgnored) return;

    logErrorBox("uncaught exception", error.message);
    console.error(c.gray(error.stack));
    logger.system("system", "Engine is still running");
  });

  process.on("unhandledRejection", (reason, promise) => {
    logErrorBox("unhandled rejection", String(reason));
    console.error(c.gray("Promise:"), promise);
    logger.system("system", "Engine is still running");
  });

  process.on("warning", (warning) => {
    logger.warn("system", `${warning.name}: ${warning.message}`);
  });

  process.on("SIGINT", async () => {
    console.log("");
    logger.system("system", "Received STOP signal (SIGINT)");
    logger.info("database", "Saving data to local storage...");
    try {
      const db = getDatabase();
      db.save();
      logger.success("database", "All data successfully saved");
    } catch (error) {
      logger.warn("database", `save failed: ${error.message}`);
    }
    logger.info("system", "Engine stopped safely");
    process.exit(0);
  });

  process.on("SIGTERM", () => {
    console.log("");
    logger.system("system", "Received TERMINATE signal (SIGTERM)");
    process.exit(0);
  });

  logger.success("system", "Anti-Crash Protection is Active");
}

async function main() {
  await playBootSequence({
    name: config.bot?.name || "Ourin-AI",
    version: config.bot?.version || "1.0.0",
    developer: config.bot?.developer || "Developer",
    mode: config.mode || "public",
  });
  setupAntiCrash();

  const dbPath = path.join(
    process.cwd(),
    config.database?.path || "./database/main",
  );
  await initDatabase(dbPath);
  const db = getDatabase();

  await spinText("system", "Starting local asset cache server...", { tone: "accent" });
  try {
  if (typeof preloadAssets === "function") await preloadAssets(config.assets);
} catch (error) {
  logger.warn("assets", `preloadAssets skipped: ${error.message}`);
}

  const savedMode = db.setting("botMode");
  if (savedMode && (savedMode === "self" || savedMode === "public"))
    config.mode = savedMode;
  const savedPremium = db.setting("premiumUsers");
  if (Array.isArray(savedPremium)) config.premiumUsers = savedPremium;
  const savedBanned = db.setting("bannedUsers");
  if (Array.isArray(savedBanned)) config.bannedUsers = savedBanned;

  const pCount = Array.isArray(savedPremium) ? savedPremium.length : 0;
  const bCount = Array.isArray(savedBanned) ? savedBanned.length : 0;
  logger.success(
    "database",
    `Database initialized | Mode: ${config.mode} | Premium: ${pCount} | Banned: ${bCount}`,
  );

  const pluginsPath = path.join(process.cwd(), "plugins");
  const pluginCount = await loadPlugins(pluginsPath);
  logger.success("plugin", `${pluginCount} modules loaded successfully`);

  if (config.dev?.enabled && config.dev?.watchPlugins)
    startDevWatcher(pluginsPath);
  if (config.dev?.enabled && config.dev?.watchSrc) {
    const srcPath = path.join(process.cwd(), "src");
    startSrcWatcher(srcPath);
  }

  try {
    initScheduler(config);
    logger.success("scheduler", "core scheduler initialized");
  } catch (e) {
    logger.warn("scheduler", "core scheduler skipped: " + e.message);
  }

  const bootTime = Date.now() - startTime;
  logger.success("boot", `System initialized in ${bootTime}ms`);
  divider();
  await spinText("network", "Opening WhatsApp connection tunnel...", {
    duration: 900,
    tone: "accent",
  });
  logConnection("connecting", "Establishing session and handshake protocol");
  console.log("");

  await startConnection({
    onRawMessage: async (msg, sock) => {
      try {
        const db = getDatabase();
        await handleAntiTagSW(msg, sock, db);
      } catch (error) { }
    },

    onMessage: async (msg, sock) => {
      try {
        const handlerPromise = messageHandler(msg, sock);
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Handler timeout")), 60000),
        );
        await Promise.race([handlerPromise, timeoutPromise]);
      } catch (error) {
        if (error.message !== "Handler timeout") {
          logger.error("HANDLER", error.message);
          if (config.dev?.debugLog) console.error(c.gray(error.stack));
        }
      }
    },

    onGroupUpdate: async (update, sock) => {
      try {
        if (typeof groupHandler === "function") await groupHandler(update, sock);
      } catch (error) {
        logger.error("GROUP", error.message);
      }
    },

    onMessageUpdate: async (updates, sock) => {
      try {
        await messageUpdateHandler(updates, sock);
      } catch (error) {
        logger.error("MSG", error.message);
      }
    },

    onGroupSettingsUpdate: async (update, sock) => {
      try {
        await groupSettingsHandler(update, sock);
      } catch (error) {
        logger.error("GROUP", error.message);
      }
    },

    onStubMessage: async (msg, sock) => {
      try {
        const db = getDatabase();
        await handleAntiRemoveFromUpsert(msg, sock, db);
      } catch (error) {
        logger.error("ANTIDELETE", error.message);
      }
    },

    onConnectionUpdate: async (update, sock) => {
      if (update.connection === "open") {
        logConnection("connected", sock.user?.name || "Bot");
        loadScheduledMessages(sock);
        startGroupScheduleChecker(sock);
        startSewaChecker(sock);
        initScheduler(config, sock);
        initAutoJpmScheduler(sock);
        initSholatScheduler(sock);
        initNotifScheduler(sock);
        initWeatherScheduler(sock);
        initLokerScheduler(sock);
        try {
          const { initSahurCron } =
            await import("./plugins/religi/autosahur.js");
          initSahurCron(sock);
        } catch { }
        try {
          const { startOrderPoller } = await import("./src/lib/ourin-order-poller.js");
          if (typeof startOrderPoller === "function") {
            try {
              startOrderPoller(sock);
            } catch (e) {
              logger.warn("ORDER", `startOrderPoller failed during start: ${e.message}`);
            }
          } else {
            logger.warn("ORDER", "startOrderPoller not exported or not a function");
          }
        } catch (e) {
          logger.warn("ORDER", `startOrderPoller unavailable: ${e.message}`);
        }
        try {
          const { startOtpPoller: _startOtp } =
            await import("./src/lib/ourin-otp-poller.js");
          _startOtp(sock);
        } catch { }

        try {
          const { getAllJadibotSessions, restartJadibotSession } =
            await import("./src/lib/ourin-jadibot-manager.js");
          const sessions = getAllJadibotSessions();
          if (sessions.length > 0) {
            logger.info("JADIBOT", `Restoring ${sessions.length} session(s)`);
            for (const session of sessions) {
              try {
                await restartJadibotSession(sock, session.id);
                await new Promise((r) => setTimeout(r, 3000));
              } catch (e) {
                logger.error(
                  "JADIBOT",
                  `Failed restore ${session.id}: ${e.message}`,
                );
              }
            }
          }
        } catch (e) {
          logger.error("JADIBOT", `Gagal memulihkan: ${e.message}`);
        }

        const devLabel = config.dev?.enabled ? ` ${c.yellow("• dev")}` : "";
        startMemoryMonitor();
        startTempCleaner();
        startDailyPruner();
        logger.success("ready", `All subsystems are fully operational${devLabel}`);
        divider();
      }
    },
  });
}

main().catch((error) => {
  try {
    console.error("[FATAL] " + (error?.code || "") + " :: " + (error?.message || String(error)));
    if (error?.stack) console.error(error.stack);
    const missing = /Cannot find module ['"](.+?)['"]/.exec(String(error?.message || ""));
    if (missing) console.error("[MISSING] " + missing[1]);
  } catch {}
  logErrorBox("Fatal Error", error.message);
  console.error(c.gray(error.stack));
  process.exit(1);
});
